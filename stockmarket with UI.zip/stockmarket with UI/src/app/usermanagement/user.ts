export class user
{
    username:string |any;
    password:string |any;

   

}