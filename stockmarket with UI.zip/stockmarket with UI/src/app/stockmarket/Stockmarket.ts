import { Time } from "@angular/common";

export class Stockmarket{
    companyCode:number |any;
    companysName:string | any;
    companysCEO:string | any;
    companyTurnover:number |any;
    companyWebsite:string | any;
    stockExchange:string | any;
    stockprice:number |any;
    time:Date|any;
    active: boolean|any;
}